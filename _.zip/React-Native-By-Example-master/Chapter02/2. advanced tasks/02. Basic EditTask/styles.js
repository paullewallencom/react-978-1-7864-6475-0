import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  editTaskContainer: {
    flex: 1
  },
  editTaskText: {
    fontSize: 36,
    paddingTop: 65
  }
})

export default styles;
