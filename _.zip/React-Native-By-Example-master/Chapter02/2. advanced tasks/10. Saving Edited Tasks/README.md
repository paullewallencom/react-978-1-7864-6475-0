# Notes about this section

This is a bit different from what I have in the book right now. I refactored a few things.